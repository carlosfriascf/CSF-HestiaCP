#!/bin/sh

echo "This plugin is updated by updating csf from the root shell"

exit 0;
